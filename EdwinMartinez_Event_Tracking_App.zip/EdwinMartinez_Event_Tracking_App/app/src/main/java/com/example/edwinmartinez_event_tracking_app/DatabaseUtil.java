package com.example.edwinmartinez_event_tracking_app;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import android.content.ContentValues;
import android.database.Cursor;

public class DatabaseUtil extends SQLiteOpenHelper
{

    private static final String DATABASE_NAME = "EventTracking.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseUtil(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {

        // Stores registered user accounts
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password TEXT NOT NULL)");

        // Stores events created by users
        db.execSQL("CREATE TABLE events (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT NOT NULL, " +
                "date TEXT, " +
                "time TEXT, " +
                "description TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS events");
        onCreate(db);
    }

    // create a new user account if the username is not already taken
    public boolean createAccount(String username, String password)
    {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        long result = db.insert("users", null, values);

        return result != -1;
    }

    // check whether the username and password match an existing account
    public boolean validateLogin(String username, String password)
    {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT id FROM users WHERE username = ? AND password = ?", new String[]{username, password});

        boolean valid = cursor.moveToFirst();
        cursor.close();

        return valid;
    }

    // save a new event to the database
    public boolean addEvent(String name, String date, String time, String description)
    {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("date", date);
        values.put("time", time);
        values.put("description", description);

        long result = db.insert("events", null, values);

        return result != -1;
    }

    // retrieve all saved events from the database
    public Cursor getAllEvents()
    {
        SQLiteDatabase db = getReadableDatabase();

        return db.rawQuery("SELECT * FROM events ORDER BY id DESC", null);
    }

    // delete an event using its unique database ID
    public boolean deleteEvent(int eventId)
    {
        SQLiteDatabase db = getWritableDatabase();

        int rowsDeleted = db.delete("events", "id = ?", new String[]{String.valueOf(eventId)});

        return rowsDeleted > 0;
    }

    // update an existing event using its database ID
    public boolean updateEvent(int eventId, String name, String date, String time, String description)
    {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("date", date);
        values.put("time", time);
        values.put("description", description);

        int rowsUpdated = db.update("events", values, "id = ?", new String[]{String.valueOf(eventId)});

        return rowsUpdated > 0;
    }


}