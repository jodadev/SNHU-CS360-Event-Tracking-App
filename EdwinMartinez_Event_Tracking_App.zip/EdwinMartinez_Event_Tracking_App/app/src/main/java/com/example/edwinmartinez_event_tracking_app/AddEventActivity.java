package com.example.edwinmartinez_event_tracking_app;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View;
import android.widget.TextView;

public class AddEventActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_event);

        // element/Object declarations
        EditText eventName = findViewById(R.id.EventNameInput);
        EditText eventDate = findViewById(R.id.EventDateInput);
        EditText eventTime = findViewById(R.id.EventTimeInput);
        EditText eventDescription = findViewById(R.id.EventDescInput);
        Button saveEventButton = findViewById(R.id.SaveEventBtn);
        Button backbtn = findViewById(R.id.BackBtn);
        Button deleteEventButton = findViewById(R.id.DeleteEventBtn);
        TextView eventTitle = findViewById(R.id.AddTitle);
        DatabaseUtil databaseUtil = new DatabaseUtil(this);
        int eventId = getIntent().getIntExtra("eventId", -1);

        // show editing options only when an existing event was selected, else act as the Add Event screen
        if (eventId != -1)
        {
            eventTitle.setText("Edit Event");
            deleteEventButton.setVisibility(View.VISIBLE);

            eventName.setText(getIntent().getStringExtra("name"));
            eventDate.setText(getIntent().getStringExtra("date"));
            eventTime.setText(getIntent().getStringExtra("time"));
            eventDescription.setText(getIntent().getStringExtra("description"));
        }
        else
        {
            eventTitle.setText("Add Event");
            deleteEventButton.setVisibility(View.GONE);
        }

        // On delete, delete the selected event and return to the Events screen
        deleteEventButton.setOnClickListener(v ->
        {
            if (databaseUtil.deleteEvent(eventId))
            {
                Toast.makeText(this, "Event deleted", Toast.LENGTH_SHORT).show();
                finish();
            }
            else
            {
                Toast.makeText(this, "Failed to delete event", Toast.LENGTH_SHORT).show();
            }
        });

        // On back btn, return back to main screen without saving
        backbtn.setOnClickListener(v ->
        {
            finish();
        });

        // On save btn, save the event to database
        saveEventButton.setOnClickListener(v ->
        {
            String name = eventName.getText().toString().trim();
            String date = eventDate.getText().toString().trim();
            String time = eventTime.getText().toString().trim();
            String description = eventDescription.getText().toString().trim();

            if (name.isEmpty())
            {
                Toast.makeText(this, "Enter an event name", Toast.LENGTH_SHORT).show();
                return;
            }

            // update an existing event or save a new one.
            boolean success;

            if (eventId != -1)
            {
                success = databaseUtil.updateEvent(eventId, name, date, time, description);
            }
            else
            {
                success = databaseUtil.addEvent(name, date, time, description);
            }

            // user alert for success or fail
            if (success)
            {
                Toast.makeText(this, "Event saved", Toast.LENGTH_SHORT).show();
                finish();
            }
            else
            {
                Toast.makeText(this, "Failed to save event", Toast.LENGTH_SHORT).show();
            }
        });
    }
}