package com.example.edwinmartinez_event_tracking_app;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.widget.Button;

import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // element/Object declarations
        Button loginButton = findViewById(R.id.LoginBtn);
        EditText usernameField = findViewById(R.id.Username);
        EditText passwordField = findViewById(R.id.Password);
        Button createAccountButton = findViewById(R.id.CreateAccountBtn);
        DatabaseUtil databaseUtil = new DatabaseUtil(this);

        // Login: Only allow login when the credentials match a saved account using validation function
        loginButton.setOnClickListener(v ->
        {
            String username = usernameField.getText().toString().trim();
            String password = passwordField.getText().toString();

            if (databaseUtil.validateLogin(username, password))
            {
                Intent intent = new Intent(MainActivity.this, EventsActivity.class);
                startActivity(intent);
            }
            else
            {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        });

        // create Account: use data from fields and use the createAccount function to process
        createAccountButton.setOnClickListener(v ->
        {
            String username = usernameField.getText().toString().trim();
            String password = passwordField.getText().toString();

            // check for empty input
            if (username.isEmpty() || password.isEmpty())
            {
                Toast.makeText(this, "Enter a username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            // create the account
            if (databaseUtil.createAccount(username, password))
            {
                Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();
            }
            else
            {
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            }
        });


    }
}