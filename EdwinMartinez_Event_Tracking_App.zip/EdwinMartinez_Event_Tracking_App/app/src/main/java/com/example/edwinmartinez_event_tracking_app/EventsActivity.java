package com.example.edwinmartinez_event_tracking_app;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.widget.Button;
import android.database.Cursor;
import android.graphics.Color;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

public class EventsActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_events);


        Button addEventButton = findViewById(R.id.AddEventBtn);
        Button notificationsBtn = findViewById(R.id.NotificationsBtn);

        // Open add event screen
        addEventButton.setOnClickListener(v ->
        {
            Intent intent = new Intent(EventsActivity.this, AddEventActivity.class);
            startActivity(intent);
        });

        // Open notfications screen
        notificationsBtn.setOnClickListener(v ->
        {
            Intent intent = new Intent(EventsActivity.this, NotificationsActivity.class);
            startActivity(intent);
        });
    }

    // Sends an SMS reminder if notifications are enabled and permission is granted
    private void sendEventReminder(String eventName)
    {
        SharedPreferences preferences =
                getSharedPreferences("NotificationSettings", MODE_PRIVATE);

        boolean enabled = preferences.getBoolean("notificationsEnabled", false);
        String phoneNumber = preferences.getString("phoneNumber", "").trim();

        // return early if any of these conditions are met
        if (!enabled || phoneNumber.isEmpty() ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                        != PackageManager.PERMISSION_GRANTED)
        {
            return;
        }

        SmsManager smsManager = getSystemService(SmsManager.class);

        // attempt to send the SMS message
        if (smsManager != null)
        {
            try
            {
                smsManager.sendTextMessage(
                        phoneNumber,
                        null,
                        "Upcoming event reminder: " + eventName,
                        null,
                        null
                );
                android.util.Log.d("SMS_TEST", "SMS send request submitted successfully");
            } catch (Exception e)
            {
                // Allow the app to continue if SMS sending fails but log that it failed.
                android.util.Log.e("SMS_TEST", "SMS request failed", e);
            }
        }
    }

    // Display all saved events in the table
    private void loadEvents()
    {
        TableLayout table = findViewById(R.id.tableLayout);
        DatabaseUtil databaseUtil = new DatabaseUtil(this);

        // Start by removing old event rows while keeping the header
        table.removeViews(1, table.getChildCount() - 1);

        // use the database util function to get all events data from database
        Cursor cursor = databaseUtil.getAllEvents();

        // iterate through the data
        while (cursor.moveToNext())
        {
            TableRow row = new TableRow(this);

            int eventId = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
            String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
            String time = cursor.getString(cursor.getColumnIndexOrThrow("time"));
            String description = cursor.getString(cursor.getColumnIndexOrThrow("description"));

            String[] values = {name, date, time};

            // if the event is upcoming, send a reminder - note, duplicate messages on screen reload but to keep it simple I leave it like this
            if (isUpcomingEvent(date, time))
            {
                sendEventReminder(name);
            }

            // add the data to the row
            for (String value : values)
            {
                TextView textView = new TextView(this);
                textView.setText(value);
                textView.setTextColor(Color.BLACK);
                textView.setPadding(8, 8, 8, 8);
                row.addView(textView);
            }

            // add an Edit button which will allow the user to edit this event
            Button editButton = new Button(this);
            editButton.setText("Edit");
            editButton.setBackgroundTintList(
                    ContextCompat.getColorStateList(this, R.color.primary)
            );
            editButton.setTextColor(
                    ContextCompat.getColorStateList(this, R.color.white)
            );

            // this listener will open the Add Event screen which will act as an Edit screen for this event and pass the data to it
            editButton.setOnClickListener(v ->
            {
                Intent intent = new Intent(EventsActivity.this, AddEventActivity.class);

                intent.putExtra("eventId", eventId);
                intent.putExtra("name", name);
                intent.putExtra("date", date);
                intent.putExtra("time", time);
                intent.putExtra("description", description);

                startActivity(intent);
            });

            // lastly, add the edit button to the row then the row to the table
            row.addView(editButton);
            table.addView(row);
        }

        cursor.close();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        loadEvents(); // refresh the table when returning from the Add Event screen
    }

    // Checks whether an event starts within the next 15 minutes
    private boolean isUpcomingEvent(String date, String time)
    {
        SimpleDateFormat format =
                new SimpleDateFormat("MM/dd/yyyy h:mma", Locale.US);

        format.setLenient(false);

        try
        {
            // check date
            Date eventDate = format.parse(date.trim() + " " + time.trim());
            if (eventDate == null)
            {
                return false;
            }

            // check time
            long timeUntilEvent = eventDate.getTime() - System.currentTimeMillis();
            return timeUntilEvent >= 0 && timeUntilEvent <= 15 * 60 * 1000;

        } catch (ParseException e)
        {
            return false;
        }
    }
}