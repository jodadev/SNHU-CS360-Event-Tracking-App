package com.example.edwinmartinez_event_tracking_app;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.content.SharedPreferences;
import android.widget.Switch;
import android.widget.EditText;
import android.text.TextWatcher;
import android.text.Editable;

public class NotificationsActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_notifications);

        SharedPreferences preferences = getSharedPreferences("NotificationSettings", MODE_PRIVATE);
        Switch notificationSwitch = findViewById(R.id.NotificationSwitch);

        // restore the previous setting from the pref
        notificationSwitch.setChecked(preferences.getBoolean("notificationsEnabled", false));

        // disable notifications if SMS permission has been revoked
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED)
        {
            notificationSwitch.setChecked(false);

            preferences.edit().putBoolean("notificationsEnabled", false).apply();
        }

        // save changes when the switch is used
        notificationSwitch.setOnCheckedChangeListener((buttonView, isChecked) ->
        {

            if (isChecked && ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED)
            {
                notificationSwitch.setChecked(false);
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);

            }
            else
            {
                // save the user's notification preference
                preferences.edit().putBoolean("notificationsEnabled", isChecked).apply();
            }
        });

        // user phone number loading from pref - used when sending SMS
        EditText phoneNumberInput = findViewById(R.id.PhoneNumberInput);
        phoneNumberInput.setText(preferences.getString("phoneNumber", ""));

        // save the phone number whenever it changes
        phoneNumberInput.addTextChangedListener(new TextWatcher()
        {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count)
            {
                preferences.edit().putString("phoneNumber", s.toString()).apply();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

    }

}
